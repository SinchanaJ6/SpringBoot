package com.sinchana.my.example;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
